<template>
  <SignerList />
</template>

<script setup>
import SignerList from './components/SignerList.vue'
</script>
