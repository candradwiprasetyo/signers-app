<template>
  <div class="min-h-screen flex flex-col p-6 max-w-5xl mx-auto">
    <div class="flex justify-between">
      <h1 class="text-3xl font-bold text-gray-800 mb-2">Penandatangan SPT</h1>
      <AddButton @click="showAddModal = true" />
    </div>

    <div v-if="loading" class="text-gray-600">Loading...</div>
    <div v-else-if="error" class="text-red-600">{{ error }}</div>

    <SignersTable v-else :signers="signers" @edit="editSigner" @delete="prepareDelete" />

    <FormModal
      v-if="showAddModal"
      :signer="selectedSigner"
      @close="
        () => {
          showAddModal = false
          selectedSigner = null
        }
      "
      @saved="handleSaved"
    />

    <ConfirmModal v-if="showConfirm" @cancel="showConfirm = false" @confirm="confirmDelete" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'

import AddButton from '@/components/AddButton.vue'
import SignersTable from '@/components/SignersTable.vue'
import FormModal from '@/components/FormModal.vue'
import ConfirmModal from '@/components/ConfirmModal.vue'

const signers = ref([])
const loading = ref(true)
const error = ref('')
const showAddModal = ref(false)
const selectedSigner = ref(null)
const showConfirm = ref(false)
const deleteId = ref(null)

onMounted(fetchSigners)

async function fetchSigners() {
  try {
    const { data } = await axios.get('/api/v1/signers')
    signers.value = data.data
  } catch (error) {
    error.value = 'Gagal memuat data'
  } finally {
    loading.value = false
  }
}

function editSigner(signer) {
  selectedSigner.value = { ...signer }
  showAddModal.value = true
}

function prepareDelete(id) {
  deleteId.value = id
  showConfirm.value = true
}

async function confirmDelete() {
  showConfirm.value = false
  try {
    await axios.delete(`/api/v1/signers/${deleteId.value}`)
    signers.value = signers.value.filter((s) => s.id !== deleteId.value)
    alert('Data berhasil dihapus!')
  } catch (err) {
    alert('Gagal menghapus data.')
  }
}

function handleSaved(newSigner) {
  signers.value.push(newSigner)
}
</script>
