<template>
  <div class="min-h-screen flex flex-col p-6 max-w-5xl mx-auto">
    <div class="flex justify-between">
      <h1 class="text-3xl font-bold text-gray-800 mb-2">Penandatangan SPT</h1>
      <button
        @click="showAddModal = true"
        class="px-4 py-2 bg-red-400 hover:bg-red-500 text-white rounded-lg shadow text-xs font-bold"
      >
        TAMBAH
      </button>
    </div>

    <div v-if="loading" class="text-gray-600">Loading...</div>
    <div v-else-if="error" class="text-red-600">{{ error }}</div>

    <div v-else class="overflow-x-auto w-full">
      <div class="bg-white p-6 mt-8 rounded-xl">
        <table class="min-w-full bg-white rounded border-none">
          <thead>
            <tr>
              <th class="text-left p-3">NPWP</th>
              <th class="text-left p-3">Nama</th>
              <th class="text-left p-3">Sebagai</th>
              <th class="text-left p-3">Status</th>
              <th class="text-left p-3">Default</th>
              <th class="text-left p-3"></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="signer in signers" :key="signer.id" class="hover:bg-gray-50 transition">
              <td class="p-3 border-t">{{ formatNpwp(signer.npwp) }}</td>
              <td class="p-3 border-t">{{ signer.name }}</td>
              <td class="p-3 border-t">{{ signer.signatory }}</td>
              <td class="p-3 border-t text-center">
                <span
                  v-if="signer.statusTaxpayer === 'ACTIVEd'"
                  class="material-icons text-white bg-green-400 text-xs rounded-full w-6 h-6 flex items-center justify-center mx-auto"
                  title="Aktif"
                >
                  check
                </span>
                <span
                  v-else
                  class="material-icons text-white bg-red-400 text-xs rounded-full w-6 h-6 flex items-center justify-center mx-auto"
                  title="Aktif"
                >
                  close
                </span>
              </td>
              <td class="p-3 border-t">
                <span
                  v-if="signer.defaultSignatory"
                  class="material-icons text-white bg-green-400 text-xs rounded-full w-6 h-6 flex items-center justify-center mx-auto"
                  title="Aktif"
                >
                  check
                </span>
                <span
                  v-else
                  class="material-icons text-white bg-red-400 text-xs rounded-full w-6 h-6 flex items-center justify-center mx-auto"
                  title="Aktif"
                >
                  close
                </span>
              </td>
              <td class="p-3 border-t">
                <button
                  @click="editSigner(signer)"
                  class="px-2 py-1 bg-white hover:bg-gray-200 border text-sm rounded mr-2 font-bold text-green-500"
                >
                  <span class="material-icons text-sm"> edit </span>
                </button>
                <button
                  @click="prepareDelete(signer.id)"
                  class="px-2 py-1 bg-white hover:bg-gray-200 border text-sm rounded mr-2 font-bold text-red-500"
                >
                  <span class="material-icons text-sm"> delete </span>
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <FormModal
      v-if="showAddModal"
      :signer="selectedSigner"
      @close="
        () => {
          showAddModal = false
          selectedSigner = null
        }
      "
      @saved="handleSaved"
    />

    <ConfirmModal v-if="showConfirm" @cancel="showConfirm = false" @confirm="confirmDelete" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import FormModal from './FormModal.vue'
import ConfirmModal from './ConfirmModal.vue'

const signers = ref([])
const loading = ref(true)
const error = ref('')
const showAddModal = ref(false)
const selectedSigner = ref(null)
const showConfirm = ref(false)
const deleteId = ref(null)

onMounted(fetchSigners)

async function fetchSigners() {
  try {
    const response = await axios.get('/api/v1/signers')

    signers.value = response.data.data
  } catch (err) {
    console.error('Fetch signers error:', err)
    error.value = 'Gagal memuat data'
  } finally {
    loading.value = false
  }
}

function formatNpwp(npwp) {
  if (!npwp) return '-'
  return npwp.replace(/^(\d{2})(\d{3})(\d{3})(\d{1})(\d{3})(\d{3})$/, '$1.$2.$3.$4-$5.$6')
}

function editSigner(signer) {
  selectedSigner.value = { ...signer }
  showAddModal.value = true
}

function prepareDelete(id) {
  deleteId.value = id
  showConfirm.value = true
}

async function confirmDelete() {
  showConfirm.value = false
  try {
    await axios.delete(`/api/v1/signers/${deleteId.value}`)
    signers.value = signers.value.filter((s) => s.id !== deleteId.value)
    alert('Data berhasil dihapus!')
  } catch (err) {
    console.error('Gagal menghapus data:', err)
    alert('Gagal menghapus data.')
  }
}

function handleSaved(newSigner) {
  signers.value.push(newSigner)
}
</script>
