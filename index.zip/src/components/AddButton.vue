<template>
  <button
    @click="$emit('click')"
    class="px-4 py-2 bg-red-400 hover:bg-red-500 text-white rounded-lg shadow text-xs font-bold"
  >
    TAMBAH
  </button>
</template>
